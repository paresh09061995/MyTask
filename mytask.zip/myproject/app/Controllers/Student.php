<?php namespace App\Controllers;

use App\Models\StudentModel;
use CodeIgniter\Controller;

class Student extends Controller
{
  public function index()
{

  echo view('templates/header');
  echo view('student/student_form');
  echo view('templates/footer');
}

public function view()
{
echo view('templates/header');
echo view('student/student_view');
echo view('templates/footer');
}

public function edit($sid)
{
    $model = new StudentModel();

    $data['student'] = $model->getData($sid);

    echo view('templates/header', $data);
    echo view('student/student_data', $data);
    echo view('templates/footer', $data);

}
public function delete($s_id) {
    $model= new StudentModel();
    $data['sid']=$model->delete_row($s_id);
}

}

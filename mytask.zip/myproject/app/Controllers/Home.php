<?php namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		echo view('templates/header');
		echo view('student/student_form');
		echo view('templates/footer');
	}

}

<?php namespace App\Models;
use CodeIgniter\Model;

class StudentModel extends Model
{

    protected $table = 'tbl_student';

public function getData($student)
{

    return $this->asArray()
                ->where(['student_id' => $student])
                ->first();
}
public function delete_row($id){
    $db = \Config\Database::connect();
    $builder = $db->table('tbl_student');
    $builder->delete(['student_id' => $id]);
}
}

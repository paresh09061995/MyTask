
  <body>
    <form class="" id="Studentform"  method="post" enctype="multipart/form-data">
      <div class="form-group" align="center">

        <table border="2px">
          <tr align="center">
            <th colspan="2" >
            <h3>Student Details Form</h3>
          </th>
        </tr>
      </div>
      <div class="form-group">
        <tr>
          <td><label for="s_id" class="form-control">Student Id:</label></td>
          <td><input type="text" name="s_id" class="form-control" required></td>
        </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_email" class="form-control">Student Email:</label></td>
        <td><input type="text" name="s_email" id="s_email" class="form-control" onblur="checkEmail(this.value)" required ></td>
        <tr>
      </div>
      <div class="form-group">
        <tr>
          <td><label for="s_name" class="form-control">Student Name:</label></td>
          <td><input type="text" name="s_name" class="form-control" required></td>
      </div>
      <div class="form-group">
        <tr>
          <td><label for="s_doj" class="form-control">student DOJ:</label></td>
          <td><input type="date" name="s_doj" class="form-control" required></td>
        </tr>
      </div>
     <div class="form-group">
        <tr>
        <td><label for="s_photo" class="form-control">student Photo:</label></td>
        <td><input type="file" name="s_photo" id="s_photo" class="form-control" required onclick="validPhoto();"></td>
      </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_doc" class="form-control">support Document:</label></td>
        <td><input type="file" name="s_doc" id="s_doc"  value="<?php echo date("Y/m/d");?>" onclick="validDoc();" class="form-control" required></td>
      </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_dor" class="form-control">Date Of Registration:</label></td>
        <td><input type="date" name="s_dor" id="s_dor"class="form-control" value="<?php echo date('Y-m-d'); ?>" required></td>
      </tr>
    </div>
      <div class="form-group">
        <tr>
        <td><label for="s_dob" class="form-control">Date Of Birth:</label></td>
        <td><input type="date" name="s_dob" id="s_dob" class="form-control" onblur="count_age()" onclick="dateValidate()" required></td>
      </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_age" class="form-control">child_age:</label></td>
        <td><input type="text" name="s_age" id="s_age" class="form-control" required readonly></td>
      </tr>
      </div>
    <div class="form-group">
        <tr>
        <td><label for="s_gender"class="form-control">Gender:</label></td>
        <td>&nbsp;&nbsp;&nbsp;Male:<input type="radio" name="s_gender" value="Male">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        Female:<input type="radio" name="s_gender" value="Female"></td>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_address" class="form-control">Address:</label></td>
        <td><input type="text" name="s_address" class="form-control" required></td>
      </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_postcode" class="form-control">Postcode:</label></td>
        <td><input type="text" name="s_postcode" class="form-control" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" required></td>
      </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_status" class="form-control">Status:</label></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Active:<input type="checkbox" name="s_status" value="Active">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        InActive:<input type="checkbox" name="s_status" value="Inactive"></td>
      </tr>
      </div>
      <div class="form-group">
        <tr align="center">
        <td><input type="submit" name="submit" value="Submit" ></td>
        <td><a href="http://localhost/myproject/student/view">View</td>
      </tr>
      </div>
    </table>
      </div>
    </form>

<?php
$db = \Config\Database::connect();

if(isset($_POST['submit']))
{
$id=$_POST['s_id'];
$email=$_POST['s_email'];
$name=$_POST['s_name'];
$doj=$_POST['s_doj'];
//$photo=$_FILES['s_photo']['name'];
//$doc=$_FILES['s_doc']['name'];
$dor=$_POST['s_dor'];
$dob=$_POST['s_dob'];
$age=$_POST['s_age'];
$gender=$_POST['s_gender'];
$address=$_POST['s_address'];
$postcode=$_POST['s_postcode'];
$status=$_POST['s_status'];

$target_dir = "uploads/";
$photo = $target_dir . basename($_FILES["s_photo"]["name"]);
$photofiletype = strtolower(pathinfo($photo,PATHINFO_EXTENSION));

$dir = "uploads/";
$doc = $dir . basename($_FILES["s_doc"]["name"]);
$docfiletype = strtolower(pathinfo($doc,PATHINFO_EXTENSION));

if(($photofiletype=='jpeg' || $photofiletype=='jpg' || $photofiletype=='png' || $photofiletype=='gif') && $docfiletype=='pdf')
{
  if(move_uploaded_file($_FILES["s_photo"]["tmp_name"],$photo) && move_uploaded_file($_FILES["s_doc"]["tmp_name"],$doc))
  {

    $sql = "INSERT INTO tbl_student (student_id,student_email,student_name,student_doj,student_photo,support_document,date_of_reg,date_of_birth,child_age,gender,address,postcode,status) VALUES (".$db->escape($id).",".$db->escape($email).", ".$db->escape($name).", ".$db->escape($doj).", ".$db->escape($photo).", ".$db->escape($doc).", ".$db->escape($dor).", ".$db->escape($dob).", ".$db->escape($age).", ".$db->escape($gender).", ".$db->escape($address).", ".$db->escape($postcode).", ".$db->escape($status).")";
    $db->query($sql);
    echo $db->affectedRows();
    echo "<script>alert('Submitted')</script>";
  }
}
else {
  // code...
  echo "<script>alert('Please select valid file')</script>";
}
}
 ?>

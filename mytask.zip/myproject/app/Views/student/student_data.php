<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <body>
    <div class="container">
    <form class="" id="Studentform"  method="post" enctype="multipart/form-data">
      <div class="form-group" align="center">

        <table border="2px">
          <tr align="center">
            <th colspan="2" >
            <h3>Student Details</h3>
          </th>
        </tr>
      </div>
      <div class="form-group">
        <tr>
          <td><label for="s_id" class="form-control">Student Id:</label></td>
          <td><input type="text" name="s_id"  class="form-control"  value="<?= esc($student['student_id']); ?>" required readonly></td>
        </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_email" class="form-control">Student Email:</label></td>
        <td><input type="text" name="s_email" id="s_email" class="form-control" onblur="checkEmail(this.value)" value="<?= esc($student['student_email']); ?>" required ></td>
        <tr>
      </div>
      <div class="form-group">
        <tr>
          <td><label for="s_name" class="form-control">Student Name:</label></td>
          <td><input type="text" name="s_name" class="form-control" value="<?= esc($student['student_name']); ?>" required></td>
      </div>
      <div class="form-group">
        <tr>
          <td><label for="s_doj" class="form-control">student DOJ:</label></td>
          <td><input type="date" name="s_doj"  class="form-control" value="<?= esc($student['student_doj']); ?>" required> </td>
        </tr>
      </div>
     <div class="form-group">
        <tr>
        <td><label for="s_photo" class="form-control">student Photo:</label></td>
        <td><img src="<?php echo base_url($student['student_photo']); ?>"  height="60px" width="70px" required><input type="file" name="s_photo"  id="s_photo" onclick="validPhoto();"></td>
      </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_doc" class="form-control">support Document:</label></td>
        <td><a href="<?php echo base_url($student['support_document']); ?>">PDF</a><input type="file" name="s_doc" id="s_doc" onclick="validDoc();"></td>
      </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_dor" class="form-control">Date Of Registration:</label></td>
        <td><input type="date" name="s_dor" id="s_dor"class="form-control" value="<?= esc($student['date_of_reg']); ?>" required></td>
      </tr>
    </div>
      <div class="form-group">
        <tr>
        <td><label for="s_dob" class="form-control">Date Of Birth:</label></td>
        <td><input type="date" name="s_dob" id="s_dob" class="form-control" onblur="count_age();" onclick="dateValidate()"  value="<?= esc($student['date_of_birth']); ?>" required></td>
      </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_age" class="form-control">child_age:</label></td>
        <td><input type="text" name="s_age" id="s_age" class="form-control" value="<?= esc($student['child_age']); ?>" required readonly></td>
      </tr>
      </div>
    <div class="form-group">
        <tr>
        <td><label for="s_gender"class="form-control">Gender:</label></td>
        <td>&nbsp;&nbsp;&nbsp;Male:<input type="radio" name="s_gender" id="male" value="Male" <?php echo (($student['gender']=='Male') || ($student['gender']=='male')?'checked':''); ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        Female:<input type="radio" name="s_gender" id="female" value="Female" <?php echo (($student['gender']=='Female') || ($student['gender']=='female')?'checked':''); ?>></td>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_address" class="form-control">Address:</label></td>
        <td><input type="text" name="s_address" class="form-control" value="<?= esc($student['address']); ?>" required></td>
      </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_postcode" class="form-control">Postcode:</label></td>
        <td><input type="text" name="s_postcode" class="form-control" value="<?= esc($student['postcode']); ?>" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" required></td>
      </tr>
      </div>
      <div class="form-group">
        <tr>
        <td><label for="s_status" class="form-control">Status:</label></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Active:<input type="checkbox" name="s_status" value="Active" <?php echo (($student['status']=='Active') || ($student['status']=='active')?'checked':''); ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        InActive:<input type="checkbox" name="s_status" value="Inactive" <?php echo (($student['status']=='Inactive') || ($student['status']=='inactive')?'checked':''); ?>></td>
      </tr>
      </div>
      <div class="form-group">
        <tr align="center">
        <td><a href="http://localhost/myproject/student" name="goback">Go Back to Student form</a></td>
        <!-- <td><a href="http://localhost:8080/myproject/student/view" name="update">Update</a></td> -->
        <td><input type="submit" name="update" value="Update"></td>
      </tr>
      <tr align="center">
        <td colspan="2"><a href="http://localhost/myproject/student/view" name="goforword">View</a></td>
      </tr>
      </div>
    </table>
      </div>
    </form>
    </div>

<?php

$db = \Config\Database::connect();


if(isset($_POST['update']))
{

$id=$_POST['s_id'];
$email=$_POST['s_email'];
$name=$_POST['s_name'];
$doj=$_POST['s_doj'];
$photos=$student['student_photo'];
$docs=$student['support_document'];
$dor=$_POST['s_dor'];
$dob=$_POST['s_dob'];
$age=$_POST['s_age'];
$gender=$_POST['s_gender'];
$address=$_POST['s_address'];
$postcode=$_POST['s_postcode'];
$status=$_POST['s_status'];

$target_dir = "uploads/";
$photo = $target_dir . basename($_FILES["s_photo"]["name"]);
$photofiletype = strtolower(pathinfo($photo,PATHINFO_EXTENSION));

$dir = "uploads/";
$doc = $dir . basename($_FILES["s_doc"]["name"]);
$docfiletype = strtolower(pathinfo($doc,PATHINFO_EXTENSION));
if(move_uploaded_file($_FILES["s_photo"]["tmp_name"],$photo) || move_uploaded_file($_FILES["s_doc"]["tmp_name"],$doc))
{
  if( $photofiletype=='jpeg' || $photofiletype=='jpg' || $photofiletype=='png' || $photofiletype=='gif' || $docfiletype=='pdf')
  {
    $sql="UPDATE tbl_student SET student_email =?, student_name =?,student_doj=?,student_photo=?,support_document=?,date_of_reg=?,date_of_birth=?,child_age=?,gender=?,address=?,postcode=?,status=? WHERE student_id = ? ";
    $db->query($sql,[$email,$name,$doj,$photo,$doc,$dor,$dob,$age,$gender,$address,$postcode,$status,$id]);
    echo "<script>alert('Update successfully');</script>";
  }
  else {
    // code...
    alert('Only Image(For Photo) and PDF(For Documeny) are allowed');
  }
}
else {
  // code...
  $sql="UPDATE tbl_student SET student_email =?, student_name =?,student_doj=?,student_photo=?,support_document=?,date_of_reg=?,date_of_birth=?,child_age=?,gender=?,address=?,postcode=?,status=? WHERE student_id = ? ";
  $db->query($sql,[$email,$name,$doj,$photos,$docs,$dor,$dob,$age,$gender,$address,$postcode,$status,$id]);
  echo "<script>alert('Update successfully');</script>";
}
}
?>

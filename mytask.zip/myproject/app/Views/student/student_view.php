  <body>
    <div class="container">
    <form class="" id="Studentform" action=""  method="post" enctype="multipart/form-data">
      <?= csrf_field() ?>

      <div class="form-group" align="center">
        <h3>Student Details</h3>

        <table border="2px">

            <tr>
            <th>id</th>
            <th>email</th>
            <th>name</th>
            <th>DOj</th>
            <th>Photo</th>
            <th>DOC</th>
            <th>DOR</th>
            <th>DOB</th>
            <th>Child Age</th>
            <th>Gender</th>
            <th>Address</th>
            <th>Postcode</th>
            <th>Status</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>

      <div class="form-group">
<?php
$db = \Config\Database::connect();
$query = $db->query("SELECT * FROM tbl_student");

foreach ($query->getResultArray() as $row)
{?>
        <tr>
          <td><?php echo $row['student_id']?></td>
          <td><?php echo $row['student_email']?></td>
          <td><?php echo $row['student_name']?></td>
          <td><?php echo $row['student_doj']?></td>
          <td><img src="<?php echo base_url($row['student_photo']); ?>" height="20px" width="30px"/></td>
          <td><a href="<?php echo base_url($row['support_document']); ?>">PDF</a></td>
          <td><?php echo $row['date_of_reg']?></td>
          <td><?php echo $row['date_of_birth']?></td>
          <td><?php echo $row['child_age']?></td>
          <td><?php echo $row['gender']?></td>
          <td><?php echo $row['address']?></td>
          <td><?php echo $row['postcode']?></td>
          <td><?php echo $row['status']?></td>
          <td><a href="http://localhost/myproject/student/edit/<?php echo $row['student_id']?>">Edit</a></td>
          <td><a href="http://localhost/myproject/student/delete/<?php echo $row['student_id']?>" name="delete" onclick="return confirm('Do you want delete this record?')">Delete</a></td>
        </tr>
      </div>
<?php } ?>
    </table>

      </div>
    </form>
    </div>

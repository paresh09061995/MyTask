<!DOCTYPE html>
<html lang="en" dir="ltr">

  <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/javascript.util/0.12.12/javascript.util.min.js"></script>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Student</title>


<script type="text/javascript">

function checkEmail(str)
{
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(!re.test(str))
    alert("Please enter a valid email address");

}

function count_age()
    {
        var birthDay = document.getElementById("s_dob").value;
        var DOB = new Date(birthDay);
        var today = new Date();
        var age = today.getTime() - DOB.getTime();
        age = Math.floor(age / (1000 * 60 * 60 * 24 * 365.25));
       // alert(age);
        document.getElementById("s_age").value=age;
    }
function dateValidate()
{
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();
 if(dd<10){
        dd='0'+dd
    }
    if(mm<10){
        mm='0'+mm
    }

today = yyyy+'-'+mm+'-'+dd;
document.getElementById("s_dob").setAttribute("max", today);
}
function validPhoto()
  {
    var fname = document.getElementById('s_photo').value;
    var re = /(\.jpg|\.jpeg|\.gif|\.png)$/i;
    if(!re.exec(fname))
    {
      alert("Please select Image file Only!");
    }
  }
function validDoc()
  {
  var fname = document.getElementById('s_doc').value;
  var re = /(\.pdf)$/i;
  if(!re.exec(fname))
  {
    alert("Please select PDF file Only!");
  }
}


</script>

  </head>
